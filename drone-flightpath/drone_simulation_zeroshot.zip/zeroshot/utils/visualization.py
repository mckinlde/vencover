# Visualization (Optional)
# Use libraries such as matplotlib for simple 3D visualization.

from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
